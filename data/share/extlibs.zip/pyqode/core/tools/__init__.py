"""
This package contains generic tools that might be useful for IDE:

- console: offer an external console wrapper that prompt the user to press
  a key at the end of the console program. Useful for running short program
  in an external terminal.

"""
