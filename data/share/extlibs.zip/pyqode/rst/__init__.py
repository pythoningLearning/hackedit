"""
Adds restructured text support to pyQode.
"""


__version__ = '2.8.0.dev'
