"""
Add cobol support to pyQode.

Most of the code come from OpenCobolIDE.
"""

__version__ = '2.8.0.dev0'
