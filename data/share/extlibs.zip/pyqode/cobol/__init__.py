"""
Add cobol support to pyQode.

Most of the code come from OpenCobolIDE.
"""

__version__ = '2.7.0'
