"""
This package contains the backend code. Mainly the server and the
code completion provider.
"""
