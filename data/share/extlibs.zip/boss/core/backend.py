"""Boss Core Backend Module."""

VERSION = (0, 9, 20, 'final', 0)  # pragma: nocover
